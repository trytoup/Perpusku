from django.urls import path
from .program import home, auth, profile, denda
urlpatterns = [
    path('', home.Menu.as_view()),
    path('signin/', auth.Signin.as_view()),
    path('register/', auth.Register.as_view()),
    path('profile/', profile.Profile.as_view()),
    path('denda/', denda.main_controller),
    path('denda/<int:id>', denda.detail_controller),
    path('denda/riwayat/', denda.history_controller),
]
