from django.contrib import admin
from . import models as db
import uuid
# Register your models here.


class Feature:
    def make_barcode(self, request, queryset):
        for q in queryset:
            for i in range(0, q.stok):
                db.buku(
                    buku=q,
                    barcode=q.judul[:4].upper() + uuid.uuid4().hex[:9].upper()
                ).save()

    make_barcode.short_description = "Create mass barcode"


@admin.register(db.pengguna)
class penggunaClass(admin.ModelAdmin):
    list_display = ['phone', 'nama', 'nis', 'kelas', 'is_active']
    search_fields = ['phone', 'nama', 'nis', 'kelas']
    list_per_page = 10


@admin.register(db.kelas)
class kelasClass(admin.ModelAdmin):
    list_display = ['tingkatan', 'nama']
    search_fields = ['nama']
    list_per_page = 10


@admin.register(db.groupBuku)
class grupbuku(admin.ModelAdmin, Feature):
    list_display = ['judul', 'kelas', 'tahun', 'penerbit', 'stok']
    search_fields = ['judul', 'kelas', 'tahun', 'penerbit', 'stok']
    actions = ['make_barcode']
    list_per_page = 10


@admin.register(db.buku)
class bukuClass(admin.ModelAdmin):
    list_display = ['buku', 'barcode', 'peminjam']
    search_fields = ['barcode']
    list_per_page = 10


@admin.register(db.denda)
class dendaClass(admin.ModelAdmin):
    list_display = ['jenis', 'nominal', 'grup_buku']
    search_fields = ['jenis']
    list_per_page = 10


@admin.register(db.logPinjam)
class logClass(admin.ModelAdmin):
    list_display = ['buku', 'peminjam', 'tanggal_pinjam',
                    'tanggal_balik', 'is_lost', 'is_back', 'is_telat', 'denda']
    list_per_page = 10


@admin.register(db.logDenda)
class logDendaClass(admin.ModelAdmin):
    search_fields = ['noInvoice']
    list_display = ['noInvoice', 'users', 'total', 'method', 'status']
    list_per_page = 10


@admin.register(db.method)
class methodClass(admin.ModelAdmin):
    list_display = ['nama', 'nomor', 'namaHolder', 'type']
