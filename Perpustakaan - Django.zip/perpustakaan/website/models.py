from django.db import models
from pytz import timezone
import uuid
import datetime
from random import randint

currentDate = datetime.datetime.now()
genTicket = uuid.uuid4().hex[:8].upper()
pilihanTingkatan = (
    ('X', 'X'),
    ('XI', 'XI'),
    ('XII', 'XII')
)


class kelas(models.Model):
    nama = models.CharField(max_length=255)
    tingkatan = models.CharField(max_length=3, choices=pilihanTingkatan)

    def __str__(self):
        return self.tingkatan + ' ' + self.nama


class pengguna(models.Model):
    phone = models.CharField(max_length=15)
    nama = models.CharField(max_length=255, blank=True, null=True)
    nis = models.CharField(max_length=4)
    kelas = models.ForeignKey(
        kelas, on_delete=models.CASCADE, blank=True, null=True)
    otp = models.CharField(max_length=10, default="")
    is_active = models.BooleanField(default=False)

    def __str__(self):
        return self.phone


class groupBuku(models.Model):
    judul = models.CharField(max_length=255)
    kelas = models.CharField(max_length=255, choices=pilihanTingkatan)
    tahun = models.IntegerField()
    penerbit = models.CharField(max_length=255)
    stok = models.IntegerField()

    def __str__(self):
        return self.judul


class buku(models.Model):
    buku = models.ForeignKey(groupBuku, on_delete=models.CASCADE)
    barcode = models.CharField(max_length=255)
    peminjam = models.ForeignKey(
        pengguna, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return self.buku.judul + " - " + self.buku.kelas


class denda(models.Model):
    jenisPilihan = (
        ('TELAT', 'TELAT'),
        ('HILANG', 'HILANG')
    )
    jenis = models.CharField(max_length=255, choices=jenisPilihan)
    nominal = models.IntegerField()
    grup_buku = models.ForeignKey(groupBuku, on_delete=models.CASCADE)

    def __str__(self):
        return self.jenis


class logPinjam(models.Model):
    buku = models.ForeignKey(buku, on_delete=models.CASCADE)
    peminjam = models.ForeignKey(pengguna, on_delete=models.CASCADE)
    tanggal_pinjam = models.DateField(auto_now_add=True)
    tanggal_balik = models.DateField(
        default=currentDate + datetime.timedelta(days=10))
    is_lost = models.BooleanField(default=False)
    is_back = models.BooleanField(default=False)
    is_telat = models.BooleanField(default=False)
    denda = models.ForeignKey(
        denda, on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        return self.buku.buku.judul + ' - ' + self.peminjam.nama


class method(models.Model):
    TYPE = (
        ("OTOMATIS", "OTOMATIS"),
        ("MANUAL", "MANUAL")
    )
    nama = models.CharField(max_length=50)
    nomor = models.CharField(max_length=50, default="082269789818")
    namaHolder = models.CharField(max_length=255)
    type = models.CharField(max_length=10, choices=TYPE)

    def __str__(self):
        return self.nama


class logDenda(models.Model):
    STATUS = (
        ('PENDING', 'PENDING'),
        ('SUKSES', 'SUKSES'),
        ('DIBATALKAN', 'DIBATALKAN')
    )

    users = models.ForeignKey(to="pengguna", on_delete=models.CASCADE)
    noInvoice = models.CharField(max_length=8, default=genTicket)
    time = models.DateTimeField(
        default=currentDate.replace(tzinfo=timezone('Asia/Jakarta')))
    method = models.ForeignKey(method, on_delete=models.CASCADE)
    total = models.IntegerField()
    kodeUnik = models.IntegerField(default=000)
    status = models.CharField(max_length=11, choices=STATUS, default="PENDING")
    buku = models.ForeignKey(logPinjam, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.noInvoice} | {self.status} - {self.total} | {self.method.nama}"
