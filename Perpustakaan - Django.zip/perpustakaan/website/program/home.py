from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views import View
from django.apps import apps
from .. import models as db
from django.db.models import Sum
from website.apps import WebsiteConfig


class Menu(View):
    def get(self, request, *args, **kwargs):
        nis = request.session.get('user', '')
        if not nis:
            return redirect('/signin')
        query = db.pengguna.objects.filter(nis=nis)
        logPinjam = db.logPinjam.objects
        context = {
            "app": WebsiteConfig.aplikasi,
            "pengguna": query[0],
            "logPinjam": logPinjam.filter(peminjam=query[0]),
            "dipinjam": logPinjam.filter(peminjam=query[0], is_lost=False, is_back=False).count(),
            "dibalik": logPinjam.filter(peminjam=query[0], is_back=True).count(),
            "hilang": logPinjam.filter(peminjam=query[0], is_lost=True).count(),
            "totaldenda": logPinjam.filter(denda__isnull=False).aggregate(Sum("denda__nominal"))['denda__nominal__sum']
        }

        return render(request, 'home.html', context=context)

    def delete(self, request, *args, **kwargs):
        try:
            del request.session['user']
            return JsonResponse({
                "status": True,
                "message": "Anda telah berhasil keluar dari sesi Pengguna, Jangan lupa berkunjung kembali."
            })
        except:
            return JsonResponse({
                "status": False,
                "message": "Sepertinya Pengguna telah berhasil keluar, Silahkan masuk terlebih dahulu."
            })
