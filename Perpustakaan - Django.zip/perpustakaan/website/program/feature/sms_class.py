import json
import requests


class SMS:
    endpoint = "https://sms.gunapedia.com/api/sms"

    def __init__(self, api="perpusku"):
        self.api = api

    def send(self, to, message):
        req = requests.post(
            url=self.endpoint,
            headers={"Content-Type": "application/json"},
            data=json.dumps({
                "key": self.api,
                "data": {
                    "to_number": to,
                    "text": message
                }
            })
        )
        res = json.loads(json.dumps(req.json()))
        return res['status']

    def get(self):
        req = requests.get(url=self.endpoint + "?key=" + self.api)
        res = json.loads(json.dumps(req.json()))
        return res
