import json, random, phonenumbers
from .sms_class import SMS
from ... import models as db
class User_authentication(SMS):
    result = {
        "status": False
    }
    nis = ""
    query = ""
    body = {}
    otp = ""
    status = False
    
    def __init__(self, request):
        body = json.loads(request.body) if request.body else {}
        self.nis = body['nis'] if 'nis' in body else ""
        self.otp = body['otp'].upper() if 'otp' in body else ""
        self.query = db.pengguna.objects.filter(nis = self.nis)
        self.status = bool(self.query)
        
    def init_auth(self):
        notResult = self.result
        notResult['status'] = False
        if not self.query:
            notResult["message"] = "Pengguna tidak terotentikasi"
            return notResult
        
        if not self.query[0].is_active:
            notResult["message"] = "Harap terlebih dahulu untuk mengaktifkan akun Perpusku"
            return notResult
        
        otp = str(random.randint(0, 99999))
        phone = self.query[0].phone
        
        sms = SMS()
        sms.send(phone, f"(RAHASIA) Jangan Berikan kepada pihak lain / pihak yang mengaku Perpusku. Kode OTP Anda adalah {otp} untuk Masuk Perpusku.")
        
        self.query.update(otp = otp)
        
        result = self.result
        
        result['status'] = True
        result['message'] = "Silahkan masukkan kode verifikasi untuk masuk ke Aplikasi Perpusku"
        result["sent_to"] = "Berakhiran dengan " + phone[-4:]
        
        return result
    
    def check_otp(self):
        notResult = self.result
        notResult['status'] = False
        if not self.query:
            notResult["message"] = "Pengguna tidak terotentikasi"
            return notResult
        
        otp = self.otp
        realOtp = self.query[0].otp
        
        if not realOtp == otp: 
            notResult['message'] = "Kode verifikasi yang anda masukkan salah, Silahkan coba kembali!"
            return notResult
        
        result = self.result
        result['status'] = True
        result['message'] = "Yeay! Berhasil Masuk, Silahkan lanjutkan untuk mengarahkan anda ke Aplikasi Perpusku."
        return result
    
class User_registration(SMS):
    result = {
        "status": False
    }
    
    query = ""
    nis = ""
    otp = ""
    status = False
    
    def __init__(self, request):
        body = json.loads(request.body) if request.body else {}
        self.phone = body['phone'] if 'phone' in body else ""
        self.nis = body['nis'] if 'nis' in body else ""
        self.otp = body['otp'].upper() if 'otp' in body else ""
        try:
            self.phone = phonenumbers.parse(self.phone, "ID")
            self.phone = phonenumbers.format_number(self.phone, phonenumbers.PhoneNumberFormat.E164)
        except:
            self.phone = ""
        
        self.query = db.pengguna.objects.filter(phone = self.phone)
        self.query2 = db.pengguna.objects.filter(nis = self.nis)
        
        if self.query or self.query2 or not self.phone or not self.nis:
            print("hemm")
            self.status = True
        
    def init_registration(self):
        phone = self.phone
        
        if self.status:
            result = self.result
            result['message'] = "Nomor Ponsel atau NIS anda telah terdaftar pada sistem kami."
            return result
        
        self.query = db.pengguna(
            phone = phone,
            nis = self.nis,
            otp = str(random.randint(0, 99999)),
            is_active = False
        )
        self.query.save()
        
        sms = SMS()
        sms.send(self.query.phone, f"(RAHASIA) Jangan Berikan kepada pihak lain / pihak yang mengaku Perpusku. Kode OTP Anda adalah {self.query.otp} untuk Daftar Perpusku.")
        
        result = self.result
        result['status'] = True
        result["message"] = "Silahkan masukkan kode verifikasi untuk daftar ke Aplikasi Perpusku"
        result['sent_to'] = "Berakhiran dengan  " + self.query.phone[-4:]
        
        return result
        
    def check_otp(self):
        notResult = self.result
        notResult['status'] = False
        
        if not self.query:
            notResult["message"] = "Pengguna tidak terotentikasi"
            return notResult
        
        if self.query[0].is_active:
            notResult["message"] = "Akun kamu telah diaktifkan."
            return notResult
        
        realOtp = self.query2[0].otp if self.nis else self.query[0].otp
        otp = self.otp
        
        self.nis = self.query[0].nis if not self.nis else self.nis
        
        if not realOtp == otp: 
            notResult['message'] = "Kode verifikasi yang anda masukkan salah, Silahkan coba kembali"
            return notResult
        
        self.query2.update(is_active=True) if self.nis else self.query.update(is_active=True)
        result = self.result
        result['status'] = True
        result['message'] = "Yeay, Akun anda telah berhasil diaktifkan. Kami akan mengarahkan anda ke Aplikasi Perpusku."
        return result