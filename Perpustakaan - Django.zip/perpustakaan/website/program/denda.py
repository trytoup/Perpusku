from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views import View
from django.apps import apps
from .. import models as db
from website.apps import WebsiteConfig
from .feature import users_class
import json
from datetime import datetime
from random import randint
from . import home
import uuid


def main_controller(request):
    return views(request) if not request.method == 'POST' else ajax_denda(request) if request.session.get('user', '') else redirect('/signin/')


def detail_controller(request, id):
    return detail(request, id) if not request.method == 'POST' else ajax_confirmDenda(request, id) if request.session.get('user', '') else redirect('/signin/')


def history_controller(request):
    return history(request) if request.session.get('user', '') else redirect('/signin/')


def views(request):
    session = request.session.get('user', '')

    if not session:
        return redirect('/signin')

    query = db.pengguna.objects.filter(nis=session)
    logPinjam = db.logPinjam.objects
    context = {
        "app": WebsiteConfig.aplikasi,
        "pengguna": query[0],
        "logPinjam": logPinjam.filter(peminjam=query[0]),
        "paymentoto": db.method.objects.filter(type="OTOMATIS"),
        "paymentman": db.method.objects.filter(type="MANUAL"),

    }

    return render(request, 'denda.html', context=context)


def detail(request, id, *args, **kwargs):
    acc = db.pengguna.objects.filter(nis=request.session.get('user', ''))
    session = request.session.get('user', '')

    if not session:
        return redirect('/signin')

    invoice = db.logDenda.objects.filter(users__in=acc, id=id)

    if not invoice:
        return redirect('/denda/riwayat/')

    totaldenda = invoice[0].kodeUnik + \
        invoice[0].total if invoice[0].method.type == "OTOMATIS" else 0 + \
        invoice[0].total

    context = {
        "pengguna": acc[0],
        "app": WebsiteConfig.aplikasi,
        "invoice": invoice[0],
        "logDenda": invoice,
        "totaldenda": totaldenda
    }

    return render(request, 'invoice.html', context=context)


def history(request):
    acc = db.pengguna.objects.filter(nis=request.session.get('user', ''))
    session = request.session.get('user', '')

    if not session:
        return redirect('/signin')

    riwayatDenda = db.logDenda.objects.filter(users__in=acc).order_by('-id')

    context = {
        "app": WebsiteConfig.aplikasi,
        "acc": acc[0],
        "riwayatDenda": riwayatDenda
    }

    return render(request, 'riwayat_denda.html', context)


def ajax_confirmDenda(request, id):
    acc = db.pengguna.objects.filter(nis=request.session.get('user', ''))
    session = request.session.get('user', '')

    if not session:
        return redirect('/signin')

    pay = db.logDenda.objects.filter(id=id, users__in=acc)

    result = {
        "status": False
    }

    if request.POST.get('type', '') == "BATAL":
        pay.update(status="DIBATALKAN")
        result['status'] = True
        result['message'] = "Kami telah membatalkan transaksi pembayaran denda Anda. Sekarang Anda dapat membayar denda baru"
        return JsonResponse(result, safe=False)

    from .payment import ovo

    if not pay:
        result['message'] = "Metode Pembayaran tidak valid, Tolong jangan mengganggu sistem!"
        return JsonResponse(result, safe=False)

    var = {
        "denda": pay[0].total,
        "codeunik": pay[0].kodeUnik,
        "method": pay[0].method.nama,
        "type": pay[0].method.type
    }

    var['total'] = var['denda'] + var['codeunik']

    if var['type'] == "MANUAL":
        result['message'] = "Anda tidak seharusnya dapat mengakses tindakan ini, Tolong jangan ganggu sistem!"
        return JsonResponse(result, safe=False)

    if var['method'] == "OVO":
        cek = ovo.byNominal(pay[0].method.nomor, var['total'])
        if cek['status'] == False:
            result['message'] = "Pembayaran Tidak Ditemukan!"
            return JsonResponse(result, safe=False)

        pay.update(status="SUKSES")

        result['status'] = True
        result['message'] = "Terima kasih telah melakukan pembayaran, denda anda lunas"

    return JsonResponse(result, safe=False)


def ajax_denda(request):
    user = db.pengguna.objects.get(nis=request.session.get('user', ''))
    method = request.POST.get('metode', '')
    total = db.logPinjam.objects.filter(id=request.POST.get('buku', ''))
    pay = db.method.objects.filter(id=int(method))
    logDen = db.logDenda.objects.filter(users=user).last()
    buku = db.logPinjam.objects.filter(id=request.POST.get('buku', ''))

    result = {
        "status": False
    }

    if not pay:
        result['message'] = "Metode Pembayaran tidak valid, Tolong jangan mengganggu sistem!"
        return JsonResponse(result, safe=False)

    if logDen:
        if logDen.status == "PENDING":
            result['message'] = "Harap selesaikan atau batalkan transaksi terakhir Anda sebelum melakukan transaksi lainnya."
            return JsonResponse(result, safe=False)

    var = {}
    var['codeunik'] = randint(111, 999)
    var['type'] = pay[0].type

    denda = db.logDenda(users=user, noInvoice=uuid.uuid4().hex[:8].upper(), method=pay[0], total=total[0].denda.nominal,
                        kodeUnik=var['codeunik'], status="PENDING", buku=buku[0])
    denda.save()

    data = {}
    data['noInvoice'] = denda.noInvoice
    data['id'] = denda.id
    data['type'] = var['type']

    result['data'] = data
    result['status'] = True

    if var['type'] == "MANUAL":
        result['message'] = "Anda dapat melakukan transaksi lalu membuat tiket untuk konfirmasi transaksi Anda."
    else:
        result['message'] = "Ayo selesaikan transaksi Anda, maka otomatis akan terkonfirmasi!"

    return JsonResponse(result, safe=False)
