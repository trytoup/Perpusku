from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views import View
from django.apps import apps
from .. import models as db
from django.db.models import Sum
from website.apps import WebsiteConfig
from .feature import users_class
import json


class Profile(View):
    def get(self, request, *args, **kwargs):
        nis = request.session.get('user', '')
        if not nis:
            return redirect('/signin')
        query = db.pengguna.objects.filter(nis=nis)
        kelas = db.kelas.objects.all()
        context = {
            "app": WebsiteConfig.aplikasi,
            "pengguna": query[0],
            "kelas": kelas,
        }

        return render(request, 'profile.html', context=context)

    def put(self, request, *args, **kwargs):
        def data(value): return json.loads(request.body).get(value, "")
        if not request.session['user']:
            return JsonResponse({
                "status": False,
                "message": "Anda belum masuk kedalam sistem"
            })

        query = db.pengguna.objects.filter(nis=request.session['user'])
        query.update(
            phone=data("phone"),
            nama=data("nama"),
            nis=data("nis"),
            kelas_id=data("kelas")
        )

        return JsonResponse({
            "status": True,
            "message": "Yeay, Data anda telah berhasil diubah",
            "data": {
                "kelas": query[0].kelas.tingkatan + " " + query[0].kelas.nama,
                "nama": query[0].nama,
                "nis": query[0].nis,
                "nope": query[0].phone
            }
        })
