from django.views import View
from django.shortcuts import render
from django.http import JsonResponse
from .feature import users_class
from website.apps import WebsiteConfig

context = {
    "app": WebsiteConfig.aplikasi
}

class Signin(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'login.html', context=context)
    
    def post(self, request, *args, **kwargs):
        auth = users_class.User_authentication(request)
        return JsonResponse(auth.init_auth(), safe=False)
    
    def put(self, request, *args, **kwargs):
        auth = users_class.User_authentication(request)
        cekotp = auth.check_otp()
        if cekotp['status']:
            request.session['user'] = auth.nis
            
        return JsonResponse(cekotp, safe=False)
        
class Register(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'register.html', context=context)
    
    def post(self, request, *args, **kwargs):
        reg = users_class.User_registration(request)
        return JsonResponse(reg.init_registration(), safe=False)
    
    def put(self, request, *args, **kwargs):
        reg = users_class.User_registration(request)
        cekotp = reg.check_otp()
        if cekotp['status']:
            request.session['user'] = reg.nis
            
        return JsonResponse(cekotp, safe=False)
    
    