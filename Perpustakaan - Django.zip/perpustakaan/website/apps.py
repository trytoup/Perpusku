from django.apps import AppConfig


class WebsiteConfig(AppConfig):
    aplikasi = {
        "nama": "Perpusku",
        "sekolah": "SMK Negeri 3 Metro",
        "alamat": "Jl.Kemiri No 15A Metro Timur",
        "desc": "Aplikasi Perpusku untuk siswa dengan fitur manejemen Pinjaman Buku di Perpustakaan yang teratur",
        "funfact": {
            "login": "Banyak orang masih tidak mengenal provinsi Lampung, Banyak yang mengira Lampung bagian dari Provinsi Sumatera Selatan. Ayo Kenalkan Lampung kepada Dunia!",
            "register": "Lampung memiliki aksara yang sering juga disebut “kagangapa”. Kita patut membanggakan sekaligus tetap melestarikan aksara Lampung ini."
        }
    }
